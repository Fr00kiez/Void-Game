module voidGame {
    requires javafx.fxml;
    requires javafx.controls;

    opens sample;
    opens sample.controllers;

    exports sample.controllers;
}
