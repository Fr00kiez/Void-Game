/*package sample;

public class Goblin extends Entities {
    public Goblin (String nameEnemies){
        String (nameEnemies);
    }
}*/
