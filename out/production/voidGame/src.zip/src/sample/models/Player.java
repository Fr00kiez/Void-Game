package sample.models;

public class Player {
    private String name;

    //Getter

    public String getName() {

        return name;
    }
    //Setter
    public void setName(String name) {

        this.name = name;
    }
}
