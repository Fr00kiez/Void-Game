/*package sample;

public class Wizard extends Entities {
    public Wizard(String nameEnemies){
        super(nameEnemies);
    }
}*/
